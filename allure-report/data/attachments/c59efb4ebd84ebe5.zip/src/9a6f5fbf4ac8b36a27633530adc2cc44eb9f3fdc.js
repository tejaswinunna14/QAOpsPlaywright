const { test, expect } = require('@playwright/test');
const { POManager } = require('../pageObjects/POManager');

const dataset = require('../Utils/POdataset.json');

for (const data of dataset) {
    test(`Client app - ${data.productName}`, async ({ page }) => {
        const poManager = new POManager(page);

        const loginPage = poManager.getLoginPage();
        await loginPage.goTo();
        await loginPage.validLogin(data.username, data.password);

        const dashboardPage = poManager.getDashboardPage();
        await dashboardPage.searchProductAddCart(data.productName);
        await dashboardPage.navigateToCart();

        await expect(
            page.locator(`h3:has-text('${data.productName}')`)
        ).toBeVisible();

        await page.locator("text=Checkout").click();

        await page.locator("[placeholder*='Country']")
            .pressSequentially("ind", { delay: 100 });

        const dropdown = page.locator(".ta-results");
        await dropdown.waitFor();

        const optionCount = await dropdown.locator("button").count();

        for (let i = 0; i < optionCount; i++) {
            const text = await dropdown.locator("button").nth(i).textContent();

            if (text.trim() === 'India') {
                await dropdown.locator("button").nth(i).click();
                break;
            }
        }

        await expect(
            page.locator(".user__name [type='text']").first()
        ).toHaveText(data.username);

        await page.locator(".btnn").click();

        await expect(page.locator(".hero-primary"))
            .toHaveText(" Thankyou for the order. ");

        const orderId = (await page.locator(
    ".em-spacer-1 .ng-star-inserted"
).textContent()).replace(/\|/g, "").trim();

console.log(orderId);

        await page.locator("button[routerlink*='myorders']").click();
        await page.locator("tbody").waitFor();

        const rows = page.locator("tbody tr");
        let orderFound = false;

        for (let i = 0; i < await rows.count(); i++) {
            const rowOrderId = (
                await rows.nth(i).locator("th").textContent()
            ).trim();

            if (orderId.includes(rowOrderId)) {
                await rows.nth(i).locator("button").first().click();
                orderFound = true;
                break;
            }
        }

        expect(orderFound).toBeTruthy();

        const orderIdDetails = (
            await page.locator(".col-text").textContent()
        ).trim();

        await expect(orderIdDetails).toContain(orderId);
    });
}